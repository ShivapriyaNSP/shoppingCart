import bcrypt from "bcryptjs";
export const data = {
  users: [
    {
      name: "John",
      email: "user@example.com",
      password: bcrypt.hashSync("1234", 8),
      isAdmin: true,
    },
  ],
  products: [
    {
      name: "brinjal",
      image: "../assets/vegetables.jpeg",
      category: "Vegetable",
      description: "1kg pack",
      price: 2,
      countInStock: 10,
    },
    {
      name: "brocolli",
      image: "../assets/vegetables.jpeg",
      category: "Vegetable",
      description: "1kg pack",
      price: 3,
      countInStock: 10,
    },
    {
      name: "beans",
      image: "../assets/vegetables.jpeg",
      category: "Vegetable",
      description: "1kg pack",
      price: 4,
      countInStock: 10,
    },
    {
      name: "Mango",
      image: "../assets/vegetables.jpeg",
      category: "Fruit",
      description: "1kg pack",
      price: 5.4,
      countInStock: 10,
    },
    {
      name: "banana",
      image: "../assets/vegetables.jpeg",
      category: "Fruit",
      description: "1kg pack",
      price: 2,
      countInStock: 10,
    },
    {
      name: "Tofu",
      image: "../assets/vegetables.jpeg",
      category: "Cheese",
      description: "100g pack",
      price: 4.25,
      countInStock: 10,
    },
    {
      name: "chiddar",
      image: "../assets/vegetables.jpeg",
      category: "VegeFruittable",
      description: "1kg pack",
      price: 4,
      countInStock: 10,
    },
  ],
};
