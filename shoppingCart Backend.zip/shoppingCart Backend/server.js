import express from "express";
import { data } from "./data.js";
import mongoose from "mongoose";
import dotenv from "dotenv";
import userRouter from "./routers/userRouter.js";
import orderRouter from "./routers/orderRouter.js";
import { graphqlHTTP } from "express-graphql";
import productRouter from "./routers/productRouter.js";
import { buildSchema } from "graphql";
dotenv.config();
var mongoDB = "mongodb://127.0.0.1/shoppingcart";
mongoose
  .connect(mongoDB, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => {
    console.log("db connected");
  });

var db = mongoose.connection;
db.on("error", console.error.bind(console, "MongoDB connection error:"));
const app = express();

app.use("/api/users", userRouter);
app.use("/api/products", productRouter);
app.use("/api/orders", orderRouter);
app.use((err, req, res, next) => {
  res.status(500).send({ message: err.message });
});

app.get("/api/products", (req, res) => {
  res.send(data.products);
});
app.use(
  "/graphql",
  graphqlHTTP({
    schema: buildSchema(`
    type products {
       _id: ID!
          name: String!
          image: String!
          category: String!
          description: String!
          price: Float!
           countInStock: String!
    }
        type RootQuery {
            products: products!
        }
        type RootMutation {
            createdOrder(name: String): String
        }
        schema {
            query: RootQuery
            mutation: RootMutation
        }
    `),
    rootValue: {
      products: () => {
        return ["Vegetables", "Fruits", "cheese"];
      },
      createdOrder: (args) => {
        const productName = args.name;
        return productName;
      },
    },
    graphiql: true,
  })
);
const port = process.env.PORT || 4000;
app.listen(port, () => {
  console.log("server is ready at ", port);
});
