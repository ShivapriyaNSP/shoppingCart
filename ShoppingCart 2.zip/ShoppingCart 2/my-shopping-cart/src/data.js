export const data = {
  products: [
    {
      id: "1",
      name: "brinjal",
      price: 2,
      image: ""
    },
    {
      id: "2",
      name: "brocolli",
      price: 4,
      image: ""
    },
    {
      id: "3",
      name: "beans",
      price: 3,
      image: ""
    }
  ]
};
